

Copyright (C) 2024 Open-Meteo

This dataset is from the Open-Meteo and was downloaded on october 09, 2024, from https://open-meteo.com/en/docs/historical-weather-api#latitude=35.6895&longitude=139.6917&start_date=1940-01-01&end_date=19&hourly=&daily=temperature_2m_mean. 